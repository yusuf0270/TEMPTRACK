# Weather app

This application is designed to keep track of the weather in different cities. 

It uses the accuweather API to retrieve information. Js is used to retrieve information and use it. Outlook is created using HTML and CSS. In HTML, bootstrap commands have been used to make it easier to work with styles.
